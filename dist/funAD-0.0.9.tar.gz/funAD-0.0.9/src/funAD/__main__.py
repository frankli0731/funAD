import datetime as dt
print(f"Hello from funAD package! Today is :{dt.datetime.now()}")